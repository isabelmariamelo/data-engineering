#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon May 27 15:23:03 2024

@author: isabelmelo
"""

from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi

#connecting to mongoDB
uri = "mongodb+srv://im2491:2W8KJb8qaZcGm3N@clusternyu.a9xelz3.mongodb.net/?retryWrites=true&w=majority&appName=ClusterNYU"
# Create a new client and connect to the server
client = MongoClient(uri, server_api=ServerApi('1'))
# Send a ping to confirm a successful connection
try:
    client.admin.command('ping')
    print("Pinged your deployment. You successfully connected to MongoDB!")
except Exception as e:
    print(e)

mydb = client["hw1"]
mycol = mydb["fx_rate"]

def find_avg(currency):
    total_fx_rate = 0
    fx_rate_count = 0
    curr_data = mycol.find({"currency": currency})
    for doc in curr_data:
        fx_rate = doc.get("fx_rate")
        if fx_rate is not None:  # Check if fx_rate exists
            total_fx_rate += fx_rate
            fx_rate_count += 1
    average_fx_rate = total_fx_rate / fx_rate_count
    return(average_fx_rate)

print("EURUSD", find_avg("EURUSD"))
print("AUDUSD", find_avg("AUDUSD"))
print("GBPUSD", find_avg("GBPUSD"))