#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun May 26 09:47:21 2024

@author: isabelmelo
homework1.py
exports data from polygon.io and imports 
into sqlite and mongo dbs
"""

import requests
from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi
from datetime import datetime as dt
from datetime import timedelta
import sqlite3
import threading
import time


def create_table(conn):
    #Creates a table named 'hw1' in the database.
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS hw1 (
            currency_pair TEXT,
            fx_rate REAL,
            fx_rate_ts INTEGER,
            entry_time REAL
        )
    """)
    conn.commit()

def insert_data(conn, currency_pair, fx_rate, fx_rate_ts, entry_time):
    """Inserts the provided data dictionary into the 'hw1' table."""
    cursor = conn.cursor()
    #SQL CODE
    cursor.execute("""
        INSERT INTO hw1 (currency_pair, fx_rate, fx_rate_ts, entry_time)
        VALUES (?, ?, ?, ?)
    """, (currency_pair, fx_rate, fx_rate_ts, entry_time))
    conn.commit()

#connecting to mongoDB
uri = "mongodb+srv://im2491:2W8KJb8qaZcGm3N@clusternyu.a9xelz3.mongodb.net/?retryWrites=true&w=majority&appName=ClusterNYU"
# Create a new client and connect to the server
client = MongoClient(uri, server_api=ServerApi('1'))
# Send a ping to confirm a successful connection
try:
    client.admin.command('ping')
    print("Pinged your deployment. You successfully connected to MongoDB!")
except Exception as e:
    print(e)

mydb = client["hw1"]
mycol = mydb["fx_rate"]

#connecting to polygon
api_key = "beBybSi8daPgsTp5yx5cHtHpYcrjp5Jq"
# Endpoint URL

urls = ["https://api.polygon.io/v1/conversion/EUR/USD?amount=100&precision=2", "https://api.polygon.io/v1/conversion/AUD/USD?amount=100&precision=2", "https://api.polygon.io/v1/conversion/GBP/USD?amount=100&precision=2"]

# Set headers with API key
headers = {
    "Authorization": f"Bearer {api_key}"
}



def fetch_and_store_data():
    for url in urls:
        try:
            #create sql db connection
            conn = sqlite3.connect('hw1.db')
            # Create the table (if it doesn't exist)
            create_table(conn)
            
            response = requests.get(url, headers=headers)
            response.raise_for_status()  # Raise an exception for non-200 status codes
            
            # Access the JSON data
            data = response.json()
            currency_pair = data['from'] + data['to']
            fx_rate_value = data['converted'] 
            fx_rate_timestamp = data['last']['timestamp']
            entry_time = dt.now().timestamp()
            
            record_entry = {"currency": currency_pair, "fx_rate": fx_rate_value, "fx_rate_ts": fx_rate_timestamp, "entry_time": entry_time}
            #insert the data mongo
            mycol.insert_one(record_entry)
            # Insert the data sql

            insert_data(conn, currency_pair, fx_rate_value, fx_rate_timestamp, entry_time)
            print(f"Data inserted successfully at {dt.now()}")
            # Close the database connection
            conn.close()
            
        except requests.exceptions.RequestException as e:
            print(f"Error: {e}")

# Set the duration for running (2 hours)
duration = 2 * 60 * 60  # 2 hours in seconds

# Start time for tracking duration
start_time = dt.now()

while (dt.now() - start_time) < timedelta(seconds=duration):
    # Create a thread to run the fetch_and_store_data function
    thread = threading.Thread(target=fetch_and_store_data)
    thread.start()

    # Sleep for 1 second to avoid overwhelming the server with requests
    time.sleep(1)



print("Data collection completed for 2 hours.")

    