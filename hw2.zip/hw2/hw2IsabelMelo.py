#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jun  3 17:45:53 2024

@author: isabelmelo
"""

import requests
from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi
from datetime import datetime as dt
import threading
import time
import sqlite3

###initialize content
#connecting to polygon
api_key = "beBybSi8daPgsTp5yx5cHtHpYcrjp5Jq"
# Endpoint URL
urls = ["https://api.polygon.io/v1/conversion/EUR/USD?amount=100&precision=2", "https://api.polygon.io/v1/conversion/AUD/USD?amount=100&precision=2", "https://api.polygon.io/v1/conversion/GBP/USD?amount=100&precision=2"]
# Set headers with API key
headers = {
   "Authorization": f"Bearer {api_key}"
   }

count = [0,0,0]
sum_vals = [0,0,0]
max_vals = [0,0,0]
min_vals = [0,0,0]
means = [0,0,0]
difs = [0,0,0]
fetch_timetamps = [0,0,0]
vols = [0,0,0]
fds = [0,0,0]
keltner_upper_bands = [0,0,0]
keltner_lower_bands = [0,0,0] 
N = [0,0,0]
currencies = ["EURUSD","AUDUSD","GBPUSD"]

def reset_data():
    for i in range(len(urls)):
       response = requests.get(urls[i], headers=headers)
       response.raise_for_status()  # Raise an exception for non-200 status codes
       #access json data
       data = response.json()
       count[i] = 1
       max_vals[i] = data['converted']
       min_vals[i] = data['converted']
       sum_vals[i] = data['converted']     
       N[i] = 0

def create_temp_table(conn):
    #Creates a table named 'hw2_temp' in the sql database.
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS hw2_temp (
            currency_pair TEXT,
            max_val REAL,
            min_val REAL,
            difference REAL,
            norm_vol REAL,
            entry_time REAL,
            fetch_timestamp REAL
        )
    """)
    conn.commit()

def insert_data_temp(conn, currency_pair, max_val, min_val,difference, norm_vol, entry_time, fetch_timestamp):
    """Inserts the provided data dictionary into the 'hw2_temp' table."""
    cursor = conn.cursor()
    #SQL CODE
    cursor.execute("""
        INSERT INTO hw2_temp (currency_pair, max_val, min_val,difference, norm_vol, entry_time, fetch_timestamp)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (currency_pair, max_val, min_val, difference, norm_vol, entry_time, fetch_timestamp))
    conn.commit()

def create_final_table(conn1):
    #Creates a table named 'hw2_final' in the sql database.
    cursor = conn1.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS hw2_final (
            currency_pair TEXT,
            max_val REAL,
            min_val REAL,
            mean REAL,
            norm_vol REAL,
            fd REAL,
            entry_time REAL,
            fetch_timestamp REAL
        )
    """)
    conn1.commit()

def insert_data_final(conn1, currency_pair, max_val, min_val, mean, norm_vol, fd, entry_time, fetch_timestamp):
    """Inserts the provided data dictionary into the 'hw2_temp' table."""
    cursor = conn1.cursor()
    #SQL CODE
    cursor.execute("""
        INSERT INTO hw2_final (currency_pair, max_val, min_val, mean, norm_vol, fd, entry_time, fetch_timestamp)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (currency_pair, max_val, min_val, mean, norm_vol, fd, entry_time, fetch_timestamp))
    conn1.commit()

def connect_mongo():
    #connecting to mongoDB
    uri = "mongodb+srv://im2491:2W8KJb8qaZcGm3N@clusternyu.a9xelz3.mongodb.net/?retryWrites=true&w=majority&appName=ClusterNYU"
    # Create a new client and connect to the server
    client = MongoClient(uri, server_api=ServerApi('1'))
    # Send a ping to confirm a successful connection
    return(client)
    
def connect_mongo_collection(client,db,col):
    try:
        client.admin.command('ping')
        print("Pinged your deployment. You successfully connected to MongoDB!")
        mydb = client[db]
        mycol = mydb[col]
        return(mycol)
    except Exception as e:
        print(e)
        return("exception")

def fetch_and_store_data(mongo_temp):  
    try:
        for i in range(len(urls)):
            #create sql db connection
            conn = sqlite3.connect('hw2_temp.db')
            # Create the table (if it doesn't exist)
            create_temp_table(conn)
            response = requests.get(urls[i], headers=headers)
            response.raise_for_status()  # Raise an exception for non-200 status codes
            
            #calculations
            data = response.json()
            count[i]+= 1
            currency_pair = data['from'] + data['to']
            if(data['converted'] > max_vals[i]):
                max_vals[i] = data['converted']
            elif(data['converted'] < min_vals[i]):
                min_vals[i] = data['converted']
            if(keltner_upper_bands[i] != 0):
                if(keltner_lower_bands[i] > data['converted'] or keltner_upper_bands[i] < data['converted']):
                    N[i]+=1
            difference = round(max_vals[i] - min_vals[i],2)
            difs[i] = difference
            sum_vals[i] += data['converted']
            mean = round(sum_vals[i]/count[i],2)
            means[i] = mean
            norm_vol = difference/mean  
            vols[i] = norm_vol
            entry_time = dt.now().timestamp()
            fetch_timestamp = data['last']['timestamp']
            fetch_timetamps[i] = fetch_timestamp
            
            #store data in mongo temp
            create_entry = {"currency_pair":currency_pair,"max_val":max_vals[i], "min_val":min_vals[i],"difference":difference, "norm_vol":norm_vol, "entry_time":entry_time, "fetch_timestamp":fetch_timestamp}
            mongo_temp.insert_one(create_entry)
            #store data in sql temp
            insert_data_temp(conn, currency_pair, max_vals[i], min_vals[i],difference, norm_vol, entry_time, fetch_timestamp)
            
            # Close the database connection
            conn.close()
            print(difference)
    except Exception as e:
            print(e)
 
def run_loop():
    mongo_client = connect_mongo()
    mongo_temp = connect_mongo_collection(mongo_client, "hw2", "temp")
    total_duration = 6 * 60  # 6 minutes in seconds
    start_time = dt.now()
    while (dt.now() - start_time).seconds < total_duration:
      fetch_and_store_data(mongo_temp)
      time.sleep(1)  # Sleep for 1 second
          
def store_final_data(currency_pair, max_val, min_val, mean, norm_vol, fd, entry_time, fetch_timestamp):
    mongo_client = connect_mongo()
    mongo_final = connect_mongo_collection(mongo_client, "hw2", "final")
    create_entry = {"currency_pair":currency_pair, "max_val":max_val, "min_val":min_val, "mean":mean, "norm_vol":norm_vol, "fd":fd, "entry_time":entry_time, "fetch_timestamp":fetch_timestamp}
    mongo_final.insert_one(create_entry)
          
    conn1 = sqlite3.connect('hw2_final.db')
    create_final_table(conn1)
    insert_data_final(conn1, currency_pair, max_val, min_val, mean, norm_vol, fd, entry_time, fetch_timestamp)
    
def main():
   
   
   for iteration in range(50):
       try:
           reset_data()
           # Create and start the thread
           thread = threading.Thread(target=run_loop)
           thread.start()
           # Wait for the thread to finish (approximately 6 minutes)
           thread.join()
           for i in range(len(urls)):
              keltner_upper_bands[i] = (means[i]) + (vols[i]*0.025)
              keltner_lower_bands[i] = (means[i]) - (vols[i]*0.025)
           print("Finished processing data for 6 minutes.")
           print("inserting to final dbs")
           for i in range(len(urls)):
               if difs[i]>0:
                   fd = N[i]/difs[i]
               else:
                   fd = 0
               store_final_data(currencies[i], max_vals[i], min_vals[i], means[i], vols[i], fd, dt.now().timestamp(), fetch_timetamps[i])  
           
           if(iteration != 49):
               print("clear temp dbs")
               client = connect_mongo()
               collection = connect_mongo_collection(client, "hw2", "temp")
               # Delete all documents in the collection
               delete_result = collection.delete_many({})
               # Print the number of documents deleted
               print(f"{delete_result.deleted_count} documents deleted.")
               
               
               conn2 = sqlite3.connect('hw2_temp.db')
               cursor = conn2.cursor()
               # Get a list of all table names
               cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
               tables = [row[0] for row in cursor.fetchall()]
               # Delete data from each table
               for table in tables:
                 cursor.execute(f"DELETE FROM {table};")  
               conn2.commit()
               conn2.close()
       except Exception as e:
            print(e)


main()


