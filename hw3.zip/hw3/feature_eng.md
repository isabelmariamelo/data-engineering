#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jun 14 20:46:52 2024

@author: isabelmelo
"""

** report on feature engineering **

1. we need to understand the goal of this experiment. 
The goal is to be able to classify currency pairs with their forecastability

2. we want to collect all _relevant_ fields. 
to do this, we had to collect the avg value, timestamps for a large amount of data over
a large amount of time, as well as keep track of the liquidity. We can perform operations to 
calculate the other values

3. our data needs to be consistent or we run the chance of introducing bugs into our forecast. 
the data set provided was not consistent, therefore we needed to perform some operations
before inserting it into the temporary database. 

4. this data set had a lot of missing data. for missing or corrupted files, I took them out of 
the analysed data set. 

HKDJPY: PARTIALLY FORECASTABLE
AUDCAD: PARTIALLY FORECASTABLE
SGDJPY: FORECASTABLE
GBPCAD: FORECASTABLE
USDNOK: FORECASTABLE
EURSEK: FORECASTABLE
GBPAUD: FORECASTABLE
EURUSD: FORECASTABLE
EURHKD: FORECASTABLE
USDHUF: FORECASTABLE
CADCHF: PARTIALLY FORECASTABLE
EURGBP: FORECASTABLE
GBPPLN: FORECASTABLE
EURDKK: PARTIALLY FORECASTABLE

the criteria i used is i took the average fd and vol. and for each currency pair

if fd < average_fd and vol < average_vol:
  return 'FORECASTABLE'
elif fd > average_fd and vol > average_vol:
  return 'NON-FORECASTABLE'
else:
  return 'PARTIALLY FORECASTABLE'


i also took the regression of the model using pycaret to verify the validity of my experiment
