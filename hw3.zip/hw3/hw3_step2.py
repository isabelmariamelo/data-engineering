#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jun 13 10:52:37 2024

@author: isabelmelo
"""

import pandas as pd
from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi
import threading
import signal
from sqlalchemy import create_engine, Table, Column, Integer, Float, String, MetaData, DateTime, select, delete, text
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from datetime import timedelta,datetime

# Event flag for stopping threads
stop_event = threading.Event()

def handle_interrupt(sig, frame):
    print("KeyboardInterrupt received, stopping threads...")
    stop_event.set()  # Set the event flag


# SQLAlchemy setup final ##################################
engine = create_engine('sqlite:///hw3_final.db', connect_args={'timeout': 40})
metadata = MetaData()
hw3_final = Table('hw3_final', metadata,
                    Column('currency_pair', String),
                    Column('data_timestamp', DateTime),
                    Column('vwap', Float),
                    Column('liquidity', Float),
                    Column('volatility', Float),
                    Column('max_val', Float),
                    Column('min_val', Float),
                    Column('fd', Float))
metadata.create_all(engine)
Session = sessionmaker(bind=engine)
session = Session()

#fetch auxiliary database
engine_aux = create_engine("sqlite:///hw3_temp.db")
Base = declarative_base()
Session_aux = sessionmaker(bind=engine_aux)
session_aux = Session_aux

class YourTable(Base):
    __tablename__ = 'hw3_temp'
    datetime = Column(DateTime,primary_key=True)
    vw = Column(Float)
    n =  Column( Integer)
    first_ts = Column( DateTime)
    currency = Column( String)


 #connecting to mongoDB
uri = "mongodb+srv://im2491:2W8KJb8qaZcGm3N@clusternyu.a9xelz3.mongodb.net/?retryWrites=true&w=majority&appName=ClusterNYU"
 # Create a new client and connect to the server
client = MongoClient(uri, server_api=ServerApi('1'))
try:
   client.admin.command('ping')
   print("Pinged your deployment. You successfully connected to MongoDB!")
   final_mongo_client = client['hw3']
   final_mongo = final_mongo_client['final']
   temp_mongo = final_mongo_client['temp']
except Exception as e:
    print(e)

def calculate_fd(N, max_value, min_value):
    return N / (max_value - min_value) if (max_value - min_value) != 0 else 1

def store_mongo_final(currency,timestamp,vwap,liquidity,volatility,max_val,min_val,fd):
    try:
        data_to_insert = {
               'currency_pair': currency,
               'data_timestamp': timestamp,
               'vwap': vwap,
               'liquidity': liquidity,
               'volatility':volatility,
               'max_val': max_val,
               'min_val': min_val,
               'fd':fd
           }
        final_mongo.insert_one(data_to_insert)
        print("Stored data in final mongo db")
    except Exception as e:
        print(f"error storing to final mongo: {e}")

def store_sql_final(session,currency,timestamp,vwap,liquidity,volatility,max_val,min_val,fd):
    try:
        # Insert the data vector into the final SQLite database
        ins_query = hw3_final.insert().values(
            currency_pair=currency,
            data_timestamp=timestamp,
            vwap=vwap,
            liquidity=liquidity,
            volatility=volatility,
            max_val=max_val,
            min_val=min_val,
            fd=fd
        )
        session.execute(ins_query)
        session.commit()  # Commit the transaction
        print("Stored data in final sql db")
    except Exception as e:
        print(f"Error storing in final SQLite DB: {e}")

def reset_calc_vals():
    max_value = 0
    min_value = float('inf')
    sum_values = 0
    total = 0
    N = 0
    num = 0
    return max_value,min_value,sum_values,total,N,num

def main():
    signal.signal(signal.SIGINT, handle_interrupt)  # Register interrupt handler
    max_value = 0
    min_value = float('inf')
    sum_values = 0
    total = 0
    prev_rate = 0
    prev_vol = 1
    N = 0
    num = 0
    
    #mongo vars
    mmax_value = 0
    mmin_value = float('inf')
    msum_values = 0
    mtotal = 0
    mprev_rate = 0
    mprev_vol = 1
    mN = 0
    mnum = 0
    
    i = 0
    processing = ""
   
    while(True):
        if stop_event.is_set():
          print("Interrupt received, stopping processing")
          return  # Gracefully exit the function
        
        with engine_aux.connect() as connection:
        #     query = select(YourTable).order_by(YourTable.datetime).limit(6)
        #     result = connection.execute(query)
        # Get earliest timestamp from SQL Database
            sql_query = "SELECT MIN(datetime) AS min_timestamp FROM hw3_temp"
            sql_text = text(sql_query)
            sql_result = connection.execute(sql_text).fetchone()
            sql_min_timestamp = sql_result[0]
            sql_six_hours_later = datetime.strptime(sql_min_timestamp, "%Y-%m-%d %H:%M:%S.%f") + timedelta(hours=6)
            # Query SQL Database with time window
            sql_query = f"""
            SELECT * FROM hw3_temp
            WHERE datetime >= '{sql_min_timestamp}' AND datetime < '{sql_six_hours_later}'
            """
            sql_text = text(sql_query)
            result = connection.execute(sql_text).fetchall()
        
        

        
            # Access data using row object attributes or indexes
        for row in result:
                    print(f"index: {row[0]}, datetime: {row[1]}, vw:{row[2]}, n:{row[3]}, currency:{row[6]}")
                    if(i == 0):
                        processing = row[6]
                    elif(processing != row[6]):
                        break
                    current_rate = row[2]
                    min_value = min(min_value, current_rate)
                    max_value = max(max_value, current_rate)
                    sum_values += current_rate
                    total += 1
                    num += row[3]
                    mean_value = sum_values / total if total else 0
                    liquidity = num/total if total != 0 else 0
                    vol = ((max_value - min_value) / mean_value) if mean_value else float('inf')
                    if vol == 0:
                        vol = 1
        
                    N += (current_rate - prev_rate) / (0.025 * prev_vol) if i != 0 else 0
                    fd = calculate_fd(N, max_value, min_value)
        
                    prev_rate = current_rate
                    prev_vol = vol
                    currency = row[6]
                    times = row[1]
        # Get earliest timestamp from MongoDB
        mongo_pipeline = [{"$group": {"_id": None, "min_timestamp": {"$min": "$datetime"}}}]
        mongo_result = list(temp_mongo.aggregate(mongo_pipeline))[0]
        mongo_min_timestamp = mongo_result["min_timestamp"]
        
        # Define time window (6 hours after)
        six_hours_later = mongo_min_timestamp + timedelta(hours=6)
        
        # Query MongoDB with time window
        mongo_filter = {"datetime": {"$gte": mongo_min_timestamp, "$lt": six_hours_later}}
        cursor = list(temp_mongo.find(mongo_filter))            
   
     
        for item in cursor:
            if(i == 0):
                processing = item['currency']
            elif(processing != item['currency']):
                break
            print(item)
            mcurrent_rate = item['vw']
            mmin_value = min(mmin_value, mcurrent_rate)
            mmax_value = max(mmax_value, mcurrent_rate)
            msum_values += mcurrent_rate
            mtotal += 1
            mnum += item['n']
            mmean_value = msum_values / mtotal if mtotal else 0
            mliquidity = mnum/mtotal if mtotal != 0 else 0
            mvol = ((mmax_value - mmin_value) / mmean_value) if mmean_value else float('inf')
            if mvol == 0:
                mvol = 1
    
            mN += (mcurrent_rate - mprev_rate) / (0.025 * mprev_vol) if i != 0 else 0
            mfd = calculate_fd(mN, mmax_value, mmin_value)
    
            mprev_rate = mcurrent_rate
            mprev_vol = mvol
            mcurrency = item['currency']
            mtimes = item['datetime']
            
            print(mcurrency)
            
        store_mongo_final(currency,times,mean_value,liquidity,vol,max_value,min_value,fd)
        store_sql_final(session,mcurrency,mtimes,mmean_value,mliquidity,mvol,mmax_value,mmin_value,mfd)
        try:
            with engine_aux.connect() as connection:
                 # Query SQL Database with time window
                 sql_query = f"""
                 DELETE FROM hw3_temp
                 WHERE datetime >= '{sql_min_timestamp}' AND datetime < '{sql_six_hours_later}'
                 """
                 sql_text = text(sql_query)
                 result = connection.execute(sql_text)
                 connection.commit()
            print("items deleted from sql")
            # Delete the data using the session (if result contains objects)
            
        except Exception as e: 
            print(f"error in sql deletion: {e}")
        
        try:
            # doc_ids = [doc["_id"] for doc in cursor]
            # temp_mongo.delete_many({"_id": {"$in": doc_ids}})
            # Delete the retrieved documents
            delete_result = temp_mongo.delete_many(mongo_filter)
            deleted_count = delete_result.deleted_count
            print(f"Deleted {deleted_count} entries from the last 6 hours.")
        except Exception as e: 
            print(f'error found in mongo del: {e}')
            
        
        max_value,min_value,sum_values,total,N,num = reset_calc_vals()
        mmax_value,mmin_value,msum_values,mtotal,mN,mnum = reset_calc_vals()
        i+=1
        if(i == 1):
            processing = mcurrency
        elif(processing != cursor[len(cursor)-1]['currency']):
            i=0
            N=0
            processing = cursor[len(cursor)-1]['currency']
            
  
if __name__ == "__main__":
  main()