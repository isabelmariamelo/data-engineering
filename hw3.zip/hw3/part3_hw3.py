#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jun 14 14:03:18 2024

@author: isabelmelo
"""

#import pandas as pd
from pycaret.regression import *
import pandas as pd
from sqlalchemy import create_engine
import numpy as np

# Connect to database
connection_string = "sqlite:///hw3_final.db"
engine = create_engine(connection_string)

# Read data from table
data = pd.read_sql_table('hw3_final', engine)  # Use pandas to read the table
cleaned_df = data.replace([np.inf, -np.inf], data['vwap'].max())

regr_setup = setup ( cleaned_df, target = 'vwap', train_size = 0.7, session_id = 123, verbose = False )

#create_model('lr')

def classify_currency_pair(vol,fd):

  if fd < average_fd and vol < average_vol:
    return 'FORECASTABLE'
  elif fd > average_fd and vol > average_vol:
    return 'NON-FORECASTABLE'
  else:
    return 'PARTIALLY FORECASTABLE'

unique_currency_pairs = cleaned_df['currency_pair'].unique()
print(unique_currency_pairs)
average_fd = cleaned_df['fd'].mean()
average_vol = cleaned_df['volatility'].mean()

 # Classify each currency pair
for cp in unique_currency_pairs:
  currency_data = cleaned_df[cleaned_df['currency_pair'] == cp]
  vol = currency_data['volatility'].mean()
  fd = currency_data['fd'].mean()
  classification = classify_currency_pair(vol,fd)
  
  print(f"{cp}: {classification}")
