#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jun 8 10:54:16 2024
@author: isabelmelo
"""

import pandas as pd
import glob
from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi
import threading
import signal
from sqlalchemy import create_engine, Table, Column, Integer, Float, String, MetaData, DateTime
from sqlalchemy.orm import sessionmaker

# Event flag for stopping threads
stop_event = threading.Event()

def handle_interrupt(sig, frame):
    print("KeyboardInterrupt received, stopping threads...")
    stop_event.set()  # Set the event flag


# SQLAlchemy setup ##################################
engine = create_engine('sqlite:///hw3_temp.db', connect_args={'timeout': 40})
metadata = MetaData()
hw3_temp = Table('hw3_temp', metadata,
                    Column('index', Integer),
                    Column('datetime', DateTime),
                    Column('vw', Float),
                    Column('n', Integer),
                    Column('first_ts', DateTime),
                    Column('last_ts', DateTime),
                    Column('currency', String))
metadata.create_all(engine)
Session = sessionmaker(bind=engine)
session = Session()
  
# Function to process and insert data for a single file
def process_file(file, temp_mongo):
 try:

     dtypes = {'vw': float, 't': int, 'n': int, 'datetime': str}
     required_columns = ['vw', 't', 'n', 'datetime']
      
     df = pd.read_csv(file, engine='c', dtype=dtypes, usecols=required_columns, chunksize=2000, parse_dates=['datetime'])

     for chunk in df:
      filtered_df = chunk.dropna(subset=required_columns)

      if not filtered_df.empty:
          data = filtered_df
          # Set the index of the dataframe to the 'timestamp' column
          data.set_index('datetime', inplace=True)  
    
        # # Resample the data by hour and apply the function
          hourly_data = data.resample('H')
          
          # Calculate the average vwap and sum of n for each hour
          hourly_data = hourly_data.agg({'vw': 'mean', 'n': 'sum'})
          
          hourly_data["first_ts"] = hourly_data.index
          hourly_data["last_ts"] = hourly_data.index + pd.Timedelta(hours=1)
          hourly_data["currency"] = file.split('/')[-1].split('.')[0]
          hourly_data = hourly_data[hourly_data['n'] > 0]
          
        # Reset the index to obtain a regular dataframe
          hourly_data = hourly_data.reset_index()
          
          # Reset the index to obtain a regular dataframe
          hourly_data = hourly_data.reset_index()
          
          if stop_event.is_set():
            print(f"Interrupt received, stopping processing of {file}")
            return  # Gracefully exit the function
          insertion = hourly_data.to_dict(orient='records')
          temp_mongo.insert_many(insertion)
          session.execute(hw3_temp.insert(), insertion)
          session.commit()


          # Close the connection

          print(hourly_data)
          
     
         

 except Exception as e:
  print(f"Error processing file {file}: {e}")
  session.close()
  # Close the connection




def main():
  #connecting to mongoDB
  uri = "mongodb+srv://im2491:2W8KJb8qaZcGm3N@clusternyu.a9xelz3.mongodb.net/?retryWrites=true&w=majority&appName=ClusterNYU"
  # Create a new client and connect to the server
  client = MongoClient(uri, server_api=ServerApi('1'))
  try:
    client.admin.command('ping')
    print("Pinged your deployment. You successfully connected to MongoDB!")
    temp_mongo_client = client['hw3']
    temp_mongo = temp_mongo_client['temp']

    
  except Exception as e:
    print(e)
   
  data_dir = "/Users/isabelmelo/Desktop/historical_fx_rates/"
  all_files = []
  all_files.extend(glob.glob(data_dir + '*.csv'))

  signal.signal(signal.SIGINT, handle_interrupt)  # Register interrupt handler

 
  for file in all_files:
        process_file(file,temp_mongo)


    # Close MongoDB connection (assuming it's in a separate function)
  client.close()

  print("All files processed!")

   
  
if __name__ == "__main__":
  main()